public class P29 {
    public static void main(String[] args) {
        System.out.println("HI");
    }
    public static void main() {
        System.out.println("Bye");
    }
}