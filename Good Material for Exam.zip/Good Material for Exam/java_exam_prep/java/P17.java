public class P17 {
    public static void main(String[] args) {
        int c;
        c='A';
        System.out.println(c);
    }
}