package com.java.junit;

public enum Gender {
	MALE, FEMALE
}
