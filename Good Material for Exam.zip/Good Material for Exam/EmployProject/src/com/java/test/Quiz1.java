package com.java.test;

public class Quiz1 {

	public static void main(String[] args) {
		int i=10;
	      i=i++ + ++i + ++i + i++ + i--;
	       //10 + 12 + 13 + 13 + 14
	      System.out.println("I value is  " +i);
	}
}
