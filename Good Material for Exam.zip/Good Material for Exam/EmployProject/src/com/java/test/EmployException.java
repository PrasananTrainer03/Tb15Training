package com.java.test;

public class EmployException extends Exception {

	EmployException(String error) {
		super(error);
	}
}
