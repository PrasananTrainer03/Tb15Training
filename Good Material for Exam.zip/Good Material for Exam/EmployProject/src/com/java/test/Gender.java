package com.java.test;

public enum Gender {
	MALE, FEMALE
}
