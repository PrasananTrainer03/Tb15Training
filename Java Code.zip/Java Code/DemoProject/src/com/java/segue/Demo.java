package com.java.segue;

class Data {

	public void dada() {
		System.out.println("Hi I am Dada Kalandar...");
	}
	
	private void chetan() {
		System.out.println("Hi I am Chetan...");
	}
	
	void harsha() {
		System.out.println("Hi I am Harshavarthan...");
	}
}

public class Demo {
	public static void main(String[] args) {
		Data obj = new Data();
		obj.dada();
		obj.harsha();
	}
}
