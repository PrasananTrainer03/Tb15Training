package com.java.ex;

public class ArgsDemo {

	public static void main(String[] args) {
		System.out.println("First Argument is  " +args[0]);
		System.out.println("Second Argument is   " +args[1]);
	}
}
