package com.java.segue;

public class EvenOdd {

	
}
