package com.java.cols;

import java.util.HashSet;
import java.util.Set;

public class SetDemo1 {

	public static void main(String[] args) {
		Set names = new HashSet();
		names.add("Latha");
		names.add("Rohit");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		System.out.println("Names are   ");
		for (Object ob : names) {
			System.out.println(ob);
		}
		
	}
}
