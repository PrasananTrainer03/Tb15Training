package com.java.cols;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHSetDemo {

	public static void main(String[] args) {
		Set names = new LinkedHashSet();
		names.add("Latha");
		names.add("Rohit");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		names.add("Rohit");
		names.add("Latha");
		names.add("Dada");
		names.add("Hemanth");
		names.add("Pooja"); 
		names.add("Hasitha");
		
		System.out.println("Names are   ");
		for (Object ob : names) {
			System.out.println(ob);
		}
		
	}
}
